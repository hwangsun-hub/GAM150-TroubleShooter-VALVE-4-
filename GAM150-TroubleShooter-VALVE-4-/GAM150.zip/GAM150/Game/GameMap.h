#pragma once
#include <raylib.h>
#include <vector>
#include "../Engine/GameObject.h"
#include "Platform.h"
#include "MapName.h"
#include "Player.h"
#include "Block.h"
#include "Spike.h"
#include "Flag.h"
#include "GlitchPlate.h"
namespace Game {
	class GameMap
	{
	public:
		GameMap();
		GameMap(MapName mapname);
		~GameMap();
		
		void LoadMap(MapName mapname);
		void Unload();
		void Load();
		void Update(Game::Player& player, double dt);
		void draw();
		MapName GetCuurentMapName();
		std::vector<Engine::GameObject*> GetGameObject();




	private:
		MapName currentMapName = MapName::STAGE3_LEVEL1;
		std::vector<std::vector<std::vector<int>>> maps;
		std::vector<Engine::GameObject*> objects;
		static constexpr int TILE_SIZE = 64;
		bool isGlitchPlateActive = false;
	};

}